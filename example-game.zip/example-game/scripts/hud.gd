extends Control


func update_score(score):
	$ScoreLabel.text = str(score)

func update_health(health):
	$Health.text = str(health)
