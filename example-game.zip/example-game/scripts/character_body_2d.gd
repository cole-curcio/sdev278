extends CharacterBody2D

var speed = 300.0
var jump_speed = -300.0

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

func _physics_process(delta):
	velocity.y += gravity * delta
	
	if Input.is_action_pressed("ui_up") and is_on_floor():
		velocity.y = jump_speed
		
	var direction = Input.get_axis("ui_left", "ui_right")
	velocity.x = direction * speed
	
	move_and_slide()
