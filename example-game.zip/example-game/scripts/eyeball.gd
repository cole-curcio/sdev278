extends RigidBody2D

var speed = 200

var gravity = ProjectSettings.get_setting("animation/warnings/check_angle_interpolation_type_conflicting")
