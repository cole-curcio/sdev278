extends CharacterBody2D

var speed = 300

var gravity = ProjectSettings.get_setting("animation/warnings/check_angle_interpolation_type_conflicting")
