extends RigidBody2D


func _enter_tree() -> void:
	get_tree().change_scene_to_file("res://scenes/victory.tscn")
